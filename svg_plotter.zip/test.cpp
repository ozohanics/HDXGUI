/*
 * something2svg.h
 *
 *  Created on: Aug 16, 2011
 *      Author: gregor
 *
 *
 *
 *

Copyright (c) <2013> Gregor Schilling - www.schiso.com

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/

#include "something2svg.h"


/***
 * input:
 * list of lines
 */
list<VAR> generate_markers_from_isolines(list<VAR6> lines)
{
	list<VAR6>::iterator iter(lines.begin()), iter2(lines.begin()), end(lines.end());
	list<VAR> result;

	unsigned int i = 0;
	while(iter != end)
	{
		iter->v[5] = i;
		++iter;
		++i;
	}

	bool changed = true;
	/// assimilate -> smalles values rules
	while(changed)
	{
		changed = false;
		iter = lines.begin();

		while(iter != end)
		{
			iter2 = lines.begin();
			while(iter2 != end)
			{
				if(iter == iter2)
				{
					++iter2;
					continue;
				}
				/// x,y,x,y,value,index
				if(iter->v[4] == iter2->v[4] && (
						iter->v[0] == iter2->v[0] && iter->v[1] == iter2->v[1] ||
						iter->v[0] == iter2->v[2] && iter->v[1] == iter2->v[3] ||
						iter->v[2] == iter2->v[0] && iter->v[3] == iter2->v[1] ||
						iter->v[2] == iter2->v[2] && iter->v[3] == iter2->v[3]))
				{
					if(iter->v[5] != iter2->v[5])
					{
						changed = true;
						iter->v[5] < iter2->v[5] ? iter2->v[5] = iter->v[5] :
								iter->v[5] = iter2->v[5];
					}
				}
				++iter2;
			}
			++iter;
		}
	}
	changed = true;
	while(changed)
	{
		changed = false;

		iter = lines.begin();
		end = lines.end();

		while(iter != end && !changed)
		{
			iter2 = lines.begin();
			while(iter2 != end && !changed)
			{
				if(iter2->v[5] == iter->v[5] && iter != iter2)
				{
					lines.erase(iter2);
					changed = true;
				}

				++iter2;
			}

			++iter;

		}

		if(!changed)
		{
			iter = lines.begin();
			if(lines.size() > 0)
			{
				result.push_back((iter->v[0]+iter->v[2])*0.5);
				result.push_back((iter->v[1]+iter->v[3])*0.5);
				result.push_back(iter->v[4]);
				lines.erase(iter);
				changed = true;
			}

		}


	}

	return result;
}

int main()
{

	SVG_clearPlotBuffer();  // clear the SVG temporary buffer

	list<VAR> function;

	function.push_back(0); // x 1
	function.push_back(2); // y 1
	function.push_back(4); // x 2
	function.push_back(4); // y 2

	// adds a list of points X,Y,X,Y ... with a function name to the SVG temporary buffer
	SVG_appendPointListBufferAS2DPlot( function,
	"TEST");

	 // writes the temporary SVG buffer to an SVG file with NAME, X-Axis name, Y-Axis title.
	writeSVGPointListBufferAS2DPlot("test.svg", 0,0,0,
	     "Rubber Materials", "Elongation", "Stress [Pa]");
}
