/* Set when gnuplot should be run automaticaly */
# define NOT_RUN_GNUPLOT 1
