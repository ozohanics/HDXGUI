// ...

VS_VERSION_INFO VERSIONINFO
    FILEVERSION 1,0,0,1
    PRODUCTVERSION 1,0,0,1
    // ...

BEGIN
    BLOCK "StringFileInfo"
    BEGIN
        BLOCK "041a04b0"
        BEGIN
            // ...

            VALUE "FileVersion", "1, 0, 0, 1"
            // ...

            VALUE "ProductVersion", "1, 0, 0, 1"
        END
    END
    // ...

END